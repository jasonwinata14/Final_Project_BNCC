package com.example.lnt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class volcalc extends AppCompatActivity {

    TextView VolumeTabung, VolumeBalok, VolumePiramid;
    EditText JariTabung, TinggiTabung,LebarBalok,TinggiBalok, PanjangBalok,AlasPiramid,TinggiPiramid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volcalc);

        VolumeBalok = findViewById(R.id.volumebalok);
        VolumePiramid = findViewById(R.id.volumepiramid);
        VolumeTabung = findViewById(R.id.volumetabung);
        JariTabung =findViewById(R.id.jaritabung);
        TinggiTabung=findViewById(R.id.tinggitabung);
        PanjangBalok=findViewById(R.id.panjangbalok);
        LebarBalok=findViewById(R.id.lebarbalok);
        TinggiBalok=findViewById(R.id.tinggibalok);
        AlasPiramid=findViewById(R.id.alaspiramid);
        TinggiPiramid=findViewById(R.id.tinggipiramid);
    }
    public void calculateVolume(View v){
        double n1,n2,n3,n4,n5,n6,n7,total1,total2,total3;
        n1=Double.parseDouble(PanjangBalok.getText().toString());
        n2=Double.parseDouble(LebarBalok.getText().toString());
        n3=Double.parseDouble(TinggiBalok.getText().toString());
        n4=Double.parseDouble(AlasPiramid.getText().toString());
        n5=Double.parseDouble(TinggiPiramid.getText().toString());
        n6=Double.parseDouble(JariTabung.getText().toString());
        n7=Double.parseDouble(TinggiBalok.getText().toString());
        total1=n1*n2*n3;
        total2=n4*n4*n5*1/3;
        total3=22/7*n6*n6*n7;
        VolumeTabung.setText(String.valueOf(total3));
        VolumeBalok.setText(String.valueOf(total1));
        VolumePiramid.setText(String.valueOf(total2));
    }
}