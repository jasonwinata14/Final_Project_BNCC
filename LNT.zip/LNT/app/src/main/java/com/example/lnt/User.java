package com.example.lnt;

public class User {
    public String IdBimbel;
    public String Email;
    public String Name;
    public String Pass;
    public String Conpass;

    public User(){}

    public User(String IdBimbel, String Email, String Name, String Pass, String Conpass){
        this.Conpass = Conpass;
        this.IdBimbel = IdBimbel;
        this.Email = Email;
        this.Name = Name;
        this.Pass = Pass;
    }
}
