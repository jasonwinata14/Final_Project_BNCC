package com.example.lnt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.wifi.hotspot2.pps.HomeSp;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            finish();
            return;
        }

        Button buttonr = findViewById(R.id.go_to_login);
        buttonr.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });

        TextView textViewToLogin = findViewById(R.id.direct_login);
         textViewToLogin.setOnClickListener(new View.OnClickListener(){
             @Override
             public void onClick(View v) {
                 directToLogin();
             }
         });
    }
    private void registerUser(){
        EditText IDBIMBEL = findViewById(R.id.idbimbel);
        EditText EMAIL = findViewById(R.id.email);
        EditText NAME = findViewById(R.id.name);
        EditText PASS = findViewById(R.id.pass);
        EditText CONPASS = findViewById(R.id.conpass);

        String IdBimbel = IDBIMBEL.getText().toString();
        String Email = EMAIL.getText().toString();
        String Name = NAME.getText().toString();
        String Pass = PASS.getText().toString();
        String Conpass = CONPASS.getText().toString();

        if(Name.length()<5){
            Toast.makeText(this, "Nama lebih dari 5 huruf", Toast.LENGTH_LONG).show();
            return;
        }

        if(!Email.contains("@") || !Email.endsWith(".com")){
            Toast.makeText(this, "Email tidak sesuai", Toast.LENGTH_LONG).show();
            return;
        }

        if(!Pass.contentEquals(Conpass)){
            Toast.makeText(this, "Password salah", Toast.LENGTH_LONG).show();
            return;
        }

        if(IdBimbel.isEmpty() || Email.isEmpty() || Name.isEmpty() || Pass.isEmpty() || Conpass.isEmpty()){
          Toast.makeText(this, "Please fill all data", Toast.LENGTH_LONG).show();
        return;
        }

        mAuth.createUserWithEmailAndPassword(Email, Pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                        User user = new User(IdBimbel, Email, Name, Pass, Conpass);
                            FirebaseDatabase.getInstance().getReference("users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    showMainActivity();
                                }
                            });
                        } else {
                            Toast.makeText(register.this, "Please fill all data", Toast.LENGTH_LONG).show();

                        }
                    }
                });

    }
    private void showMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void directToLogin(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

}
