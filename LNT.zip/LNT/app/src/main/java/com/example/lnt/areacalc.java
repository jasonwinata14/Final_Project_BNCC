package com.example.lnt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class areacalc extends AppCompatActivity {

    TextView LuasPersegi, LuasSegitiga, LuasLingkaran;
    EditText SisiPersegi, AlasSegitiga, TinggiSegitiga, JariLingkaran;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_areacalc);

        SisiPersegi = findViewById(R.id.sisipersegi);
        AlasSegitiga = findViewById(R.id.alassegitiga);
        TinggiSegitiga = findViewById(R.id.tinggisegitiga);
        JariLingkaran = findViewById(R.id.jarilingkaran);
        LuasLingkaran = findViewById(R.id.luaslingkaran);
        LuasPersegi = findViewById(R.id.luaspersegi);
        LuasSegitiga = findViewById(R.id.luassegitiga);

    }

    public void calculateArea(View v) {
        double n1,n2,n3,n4,total1,total2,total3;
        n1=Double.parseDouble(SisiPersegi.getText().toString());
        n2=Double.parseDouble(AlasSegitiga.getText().toString());
        n3=Double.parseDouble(TinggiSegitiga.getText().toString());
        n4=Double.parseDouble(JariLingkaran.getText().toString());
        total1=n1*n1;
        total2=n2*n3*0.5;
        total3=22/7*n4*n4;

        LuasSegitiga.setText(String.valueOf(total2));
        LuasPersegi.setText(String.valueOf(total1));
        LuasLingkaran.setText(String.valueOf(total3));




    }
}